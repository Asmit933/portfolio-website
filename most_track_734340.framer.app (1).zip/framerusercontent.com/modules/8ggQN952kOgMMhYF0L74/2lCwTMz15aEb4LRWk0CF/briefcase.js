let e;
var h = r => {
    if (!e) {
        const o = r.forwardRef(({
            color: n = "currentColor",
            size: t = 24,
            ...i
        }, s) => r.createElement("svg", {
            ref: s,
            xmlns: "http://www.w3.org/2000/svg",
            width: t,
            height: t,
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: n,
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            ...i
        }, r.createElement("rect", {
            x: "2",
            y: "7",
            width: "20",
            height: "14",
            rx: "2",
            ry: "2"
        }), r.createElement("path", {
            d: "M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"
        })));
        o.displayName = "Briefcase", e = o
    }
    return e
};
export {
    h as
    default
};