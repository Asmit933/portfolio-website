let n;
var d = r => {
    if (!n) {
        const o = r.forwardRef(({
            color: e = "currentColor",
            size: t = 24,
            ...i
        }, s) => r.createElement("svg", {
            ref: s,
            xmlns: "http://www.w3.org/2000/svg",
            width: t,
            height: t,
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: e,
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            ...i
        }, r.createElement("rect", {
            x: "2",
            y: "2",
            width: "20",
            height: "20",
            rx: "5",
            ry: "5"
        }), r.createElement("path", {
            d: "M16 11.37A4 4 0 1 1 12.63 8 4 4 0 0 1 16 11.37z"
        }), r.createElement("line", {
            x1: "17.5",
            y1: "6.5",
            x2: "17.51",
            y2: "6.5"
        })));
        o.displayName = "Instagram", n = o
    }
    return n
};
export {
    d as
    default
};