let o;
var s = r => {
    if (!o) {
        const t = r.forwardRef(({
            color: e = "currentColor",
            size: n = 24,
            ...d
        }, i) => r.createElement("svg", {
            ref: i,
            xmlns: "http://www.w3.org/2000/svg",
            width: n,
            height: n,
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: e,
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            ...d
        }, r.createElement("path", {
            d: "M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7"
        }), r.createElement("path", {
            d: "M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z"
        })));
        t.displayName = "Edit", o = t
    }
    return o
};
export {
    s as
    default
};