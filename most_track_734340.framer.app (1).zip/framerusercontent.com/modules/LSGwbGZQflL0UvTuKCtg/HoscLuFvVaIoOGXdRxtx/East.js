const l = t => t;
let e;
var n = t => (e || (e = l(t.createElement("path", {
    d: "M15 5l-1.41 1.41L18.17 11H2v2h16.17l-4.59 4.59L15 19l7-7-7-7z"
}), "East")), e);
export {
    n as
    default
};