let o;
var i = r => {
    if (!o) {
        const e = r.forwardRef(({
            color: t = "currentColor",
            size: n = 24,
            ...d
        }, l) => r.createElement("svg", {
            ref: l,
            xmlns: "http://www.w3.org/2000/svg",
            width: n,
            height: n,
            viewBox: "0 0 24 24",
            fill: "none",
            stroke: t,
            strokeWidth: "2",
            strokeLinecap: "round",
            strokeLinejoin: "round",
            ...d
        }, r.createElement("path", {
            d: "M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"
        })));
        e.displayName = "Folder", o = e
    }
    return o
};
export {
    i as
    default
};