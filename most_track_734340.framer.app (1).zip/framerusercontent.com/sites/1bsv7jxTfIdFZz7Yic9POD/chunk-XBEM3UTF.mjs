function t(e,a){return{description:"A sleek and modern portfolio template designed for creatives",favicon:"https://framerusercontent.com/assets/eVTjd4i7OQQ9C0ht13t6fN1Euo.png",robots:"max-image-preview:large",socialImage:"https://framerusercontent.com/assets/Drwr8lzIb44BzOEn0nNlsSJ4AWk.png",title:"Sawad"}}export{t as a};
//# sourceMappingURL=chunk-XBEM3UTF.mjs.map
